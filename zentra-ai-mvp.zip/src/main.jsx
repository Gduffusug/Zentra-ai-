import React from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App(){
  return <div className="page">
    <h1>Zentra AI</h1>
    <p>Your premium AI tools platform</p>
    <div className="cards">
      <div>AI Chat</div>
      <div>AI Writer</div>
      <div>AI Summary</div>
    </div>
  </div>
}

createRoot(document.getElementById("root")).render(<App />);
